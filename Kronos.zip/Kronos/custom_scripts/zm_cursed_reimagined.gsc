// BO7 Zombies (Kronos) - Fresh Cursed Rules, independent standalone GSC.
// Three supported gametypes only: Cursed, Cursed Survival, Mister Peeks Mayhem.
// No legacy progression, rarity, Arsenal, wall-weapon, or HUD modifications.
// SOURCE BUILD: not compiled or runtime tested; verify in an offline game.
//
// Update (rev. B): + Rounds 1-10 use the stock round-11 zombie attack damage tier
//                  + Players start with 0 GobbleGums loaded (was 3)
// Update (rev. C): - Removed forced 1911 "The Classic" blueprint swap
//                  + Starting 1911 uses each player's own saved Zombie Build
// Update (rev. D): + White, non-PaP 1911 damage on normal zombies uses fixed
//                    classic BO1 values by hit location (8 leg shots survive,
//                    knife finishes; chest x1.25, abdomen x1.1, head x3.5)
// Update (v3.3):   - Arsenal: pressing Use can briefly put a non-gun (use gesture /
//                    hands) in getcurrentweapon(); the target is now the held
//                    primary (getcurrentprimaryweapon fallback)
// Update (v3.23):  ~ Field Upgrades: fixed 40-kill charge, no increase per use
//                    (TEDD task charge overrides still work)
// Update (v3.22):  + Classic knife built in: the stock "perk + augment" check
//                    (shared func #"zombie" hash_3930894d8d2f0ee6) answers yes
//                    for Melee Macchiato + Mocha Maul for every player, so all
//                    stock Mocha Maul code runs without the perk
//                  - Watcher simplified (no forced perk re-apply)
// Update (v3.21):  - FIX: melee-slot change test used ===, which never matched, so
//                    the perk was toggled every 0.5 s and the knife never worked
// Update (v3.20):  ~ Classic knife watcher survives downs; perk re-applied after a
//                    revive and when the melee-slot knife changes
// Update (v3.19):  ~ Classic knife without Melee Macchiato: perk re-applied by a
//                    1 s check (it was being cleared after the spawn grant)
// Update (v3.18):  - Classic PaP for Cursed / Cursed Survival removed again
//                  + Classic knife: Mocha Maul as a bonus augment (extra slot)
//                    and the knife on the melee button even without Melee
//                    Macchiato (specialty_melee_without_swap)
// Update (v3.17):  + Classic Pack-a-Punch re-enabled in Cursed / Cursed Survival,
//                    with an on-screen reminder to collect the weapon (stock
//                    10-second pickup window of the classic path)
// Update (v3.16):  - Classic PaP for Cursed / Cursed Survival reverted (weapon was
//                    lost after the animation in those modes)
//                  ~ Arsenal prompt/Lua text/purchase: one fixed range (56 units)
// Update (v3.15):  - FIX: item_spawn_allowed veto was inverted (blocked all items
//                    incl. Mystery Box weapons, allowed only Aether Tools)
//                  + Classic Pack-a-Punch in Cursed / Cursed Survival
//                  ~ Arsenal prompt text: perk-remove prompt pattern (250 ms)
// Update (v3.14):  + Box: legacy weapons back (stock Ultra rarity, Mister Peeks
//                    Mayhem scaling only, as in the original game)
//                  - Aether Tools (rarity upgrade tools) removed from every
//                    source: item spawns vetoed via "item_spawn_allowed",
//                    Chompy store tool list emptied
// Update (v3.13):  ~ Arsenal prompt range reduction 1.8 m in total (70.9 units)
// Update (v3.12):  ~ Arsenal prompt range reduction 0.8 m -> 1 m (39.4 units)
// Update (v3.11):  ~ Arsenal prompt range reduced by 0.8 m (31.5 units)
// Update (v3.10):  - Arsenal: fallback weapon restored (hint-seen primary, then
//                    self.lastweaponobj), used as-is so Wonder Weapons stay refused
//                  - Prompt text cleared as soon as the prompt's hint calls stop
// Update (v3.9):   ~ Arsenal label: dvar "cursed_arsenal_prompt" holds the text
//                    while the local player is at a machine ("" otherwise),
//                    drawn by zm_cursed_arsenal_prompt_post.lua (same design as
//                    zm_perk_remove_post.lua). Localize hook dropped.
//                  - Arsenal acts only on the weapon in hand; Wonder Weapons
//                    (iswonderweapon / ismapwonderweapon / sat_ww_*) refused,
//                    no other gun is modified and nothing is charged
// Update (v3.8):   ~ dvar "cursed_arsenal_hint" is now 1 for the whole match in
//                    the supported modes (0 elsewhere); the Lua retitles the
//                    Arsenal prompt itself. Proximity watcher removed.
// Update (v3.6):   - Arsenal: the gun is lowered while using the machine, so the
//                    weapon seen by the hint / self.lastweaponobj is used
// Update (v3.5):   - Arsenal: pool falls back to the registered level.ammo_mods
//                    table; refusal message names the exact failing check
// Update (v3.4):   - Removed "self getlastweapon()": it is a script function
//                    (inventory::getlastweapon), not an engine method, and
//                    broke the script
// Update (v3.2):   - PaP rarity: also synced after the item-based PaP pickup
//                    ("zm_packed_weapon_non_augment") and on weapon change
//                  - Arsenal: on-screen reason when a purchase is refused
// Update (v3.1):   - No calls into the arsenal namespace (both failing paths used it)
//                  - Rarity get/set through the stock shared functions
// Update (v3):     + PaP tier sets rarity (I blue, II purple, III legendary, IV ultra)
//                  + Arsenal: random Ammo Mod for 250 Salvage (no rarity upgrades)
//                  + Weapon wall-buys locked to green
//                  + Mystery Box: green regular weapons only, no Aether Tools
//                  + Starting knife uses each player's own saved Zombie Build

// script_aa3bac81ad4fc8e = stock GobbleGum core (#namespace bgb), referenced
// by this exact hashed name in stock scripts\mp\zm\points.gsc.
#using script_aa3bac81ad4fc8e;
#using scripts\common\ai\aitypes\shared\zombie\zombie_damage;
#using scripts\common\ai\aitypes\shared\zombie\zombie_utils;
#using scripts\common\callbacks;
#using scripts\common\shared_func_utility;
#using scripts\common\system;
#using scripts\common\utility;
#using scripts\common\weapon;
#using scripts\mp\ammomods\ammo_mod;
#using scripts\mp\augments\m_mod_augments;
#using scripts\mp\augments\zombie_augments;
#using scripts\mp\common\utility\perk;
#using scripts\mp\armor;
#using scripts\mp\currency;
#using scripts\mp\interaction;
#using scripts\mp\loot\common_item_weapon;
#using scripts\mp\magicbox;
#using scripts\mp\pack_a_punch;
#using scripts\mp\purchasemenu;
#using scripts\mp\common\utility\game_utility;
#using scripts\mp\common\utility\lui_game_event_aggregator;
#using scripts\mp\wallbuy;
#using scripts\mp\weaponmetadata;
#using scripts\mp\zm\systems\zm_armor;
#using scripts\mp\zm\zm_utility;

#namespace bo7_cursed_fresh;

function private autoexec __init__system__()
{
    system::register( #"bo7_cursed_fresh_rules", undefined, &init, undefined );
}

function private supported_mode()
{
    mode = game_utility::getgametype();
    return mode == "zm_rb_r_mod" || mode == "zm_rb_r_mod_survival" || mode == "zm_rb_rh_mod";
}

function init()
{
    // v3.9: text for zm_cursed_arsenal_prompt_post.lua; "" = hidden. Reset
    // first so no mode inherits a value from a previous match.
    setdvar( "cursed_arsenal_prompt", "" );
    if ( !supported_mode() )
    {
        return;
    }

    level callback::add( #"player_spawned", &on_player_spawned );
    level callback::add( "on_variant_wallbuy_spawn", &on_armor_wall_spawned );

    // PaP IV in some configurations has a menu item with mismatched tier=3.
    // The fallback applies only when the menu identifies the level4 item.
    lui_game_event_aggregator::registeronluieventcallback( &pap_four_fallback, "pap_weaponupgrade_purchase" );

    // NEW: strip the 3 GobbleGums stock pre-loads at connect (see section below).
    level callback::add( #"player_connect", &on_player_connect_gobblegums );

    level thread maintain_pap_and_starting_armor();
    level thread bind_armor_walls();
    level thread unlock_map_wonder_weapons();

    // NEW: early-round zombie attack damage tier (see section below).
    level thread install_early_round_damage_tier();

    // rev. C: starting 1911 uses the player's own Zombie Build (see section below).
    level thread install_starting_1911_build_hook();

    // rev. D: classic BO1 white-1911 damage by hit location (see section at the end).
    level zombie_utils::register_zombie_weapon_damage_callback( "sat_pi_alcor_mp", &classic_1911_leg_damage );

    // v3: weapon progression overhaul (see section at the end).
    level callback::add( "zm_packed_weapon", &on_packed_weapon_rarity );
    level callback::add( "zm_packed_weapon_non_augment", &on_packed_weapon_rarity );
    level callback::add( #"player_weapon_change", &on_weapon_change_rarity );
    level callback::add( #"player_weapon_change", &classic_knife_on_weapon_change );
    level callback::add( "zm_perk_lost", &classic_knife_on_perk_lost );
    level thread classic_knife_install_augment_check();
    level callback::add( #"on_arsenal_spawned", &on_arsenal_spawned_bind );
    level callback::add( "on_round_end", &on_round_end_lock_wallbuys );
    level thread lock_wallbuys_green_init();
    level thread lock_magicbox_green();
    level callback::add( #"item_spawn_allowed", &veto_aether_tool_spawn );

    logstring( "[BO7 Cursed Fresh] Initialized Cursed-only rules" );
}

// -------------------- PACK-A-PUNCH --------------------
function private pap_price( item )
{
    if ( !isdefined( item ) )
    {
        return 0;
    }
    if ( !isdefined( item.itemref ) )
    {
        return item.cost ?? 0;
    }

    switch ( item.itemref )
    {
        case "level1": return 5000;
        case "level2": return 20000;
        case "level3": return 35000;
        case "level4": return 50000;
    }
    return item.cost ?? 0;
}

function private pap_four_fallback( channel, menuitemindex )
{
    if ( !supported_mode() || channel != "pap_weaponupgrade_purchase" || !isdefined( menuitemindex ) )
    {
        return;
    }
    s_menu = pack_a_punch::get_pap_purchase_menu( self.origin );
    if ( !isdefined( s_menu ) )
    {
        return;
    }
    item = purchasemenu::create_item_struct( s_menu.ref, menuitemindex );
    if ( !isdefined( item ) || !isdefined( item.itemref ) || item.itemref != "level4" )
    {
        return;
    }
    if ( item.tier == 4 )
    {
        return; // A corrected menu entry is handled by the game itself.
    }
    gun = self getcurrentweapon();
    if ( !isweapon( gun ) || self pack_a_punch::get_pap_level( gun ) != 3 )
    {
        return;
    }
    if ( !self currency::attempt_purchase( #"essence", 50000, 1, undefined, #"packapunch" ) )
    {
        purchasemenu::function_93f934ea2f1c06f8( 3 );
        return;
    }
    self pack_a_punch::pap_weapon( gun, 3, 50000, undefined, #"essence" );
    purchasemenu::function_93f934ea2f1c06f8( 1 );
}

function private empty_starting_armor( player )
{
    return [ 0, 0 ];
}

function private maintain_pap_and_starting_armor()
{
    level endon( #"game_ended" );
    while ( supported_mode() )
    {
        // Stock scripts can reset max PaP from 4 to 3 for lower relic tiers.
        level.get_pap_cost_override = &pap_price;
        level.max_pack_a_punch_level = 4;
        level.startingarmoroverridefunc = &empty_starting_armor;
        // v3: stock Arsenal rarity upgrades refuse (no charge) at max 0;
        // stock relic setup otherwise sets 4 or 5.
        level.arsenal_max_weapon_rarity = 0;
        // v3.14: zm_store_chompy offers an Aether Tool only when this table
        // has an entry for the next rarity (can_player_use_type); empty =
        // the store picks another item instead (no wasted purchase).
        level.var_a90df52f7134ce0 = [];
        // v3.23: Field Upgrades always need 40 kills.
        // field_upgrades::function_547d8d27c323ad0() (the points-needed func
        // ZM puts on every Field Upgrade) returns level.var_750a1cea39c9abc8
        // when it is a number, else bundle pointsNeeded + player.superincreasecost.
        // on_field_upgrade_used() adds level.var_d8c17916fed09937 (gametype
        // bundle: 10 in Cursed) to superincreasecost after every use.
        // TEDD tasks temporarily set level.var_750a1cea39c9abc8 to 4 / 20 and
        // back to undefined, so it is only filled in while it is not a number.
        level.var_d8c17916fed09937 = 0;
        if ( !isnumber( level.var_750a1cea39c9abc8 ) )
        {
            level.var_750a1cea39c9abc8 = 40;
        }

        // The no-armor *modifier* also disables purchases. Keep it off.
        if ( isdefined( level.zm_mode_modifiers ) )
        {
            level.zm_mode_modifiers.zmmodenoarmor = 0;
        }
        wait 0.10;
    }
}

// -------------------- NO ARMOR AT SPAWN --------------------
function private on_player_spawned( params )
{
    if ( !supported_mode() || !isplayer( self ) )
    {
        return;
    }
    self.fresh_armor_bought_this_life = 0;
    self thread clear_spawn_armor();

    // rev. C: the stock starting 1911 is built from this player's own Zombie Build.
    self arm_starting_1911_build();

    // v3.18: classic knife (Mocha Maul) - see section at the end.
    self thread classic_knife_on_spawn();
}

function private clear_spawn_armor()
{
    self endon( #"disconnect" );
    // Stock armor initialization can execute one or two frames after spawn.
    wait 0.20;
    if ( !self.fresh_armor_bought_this_life )
    {
        self force_armor_zero();
    }
    wait 0.50;
    if ( !self.fresh_armor_bought_this_life )
    {
        self force_armor_zero();
    }
}

function private force_armor_zero()
{
    self.platecarrierlevel = 0;
    self.maxarmorhealth = 0;
    self.hasgoldenarmorplate = 0;
    self setclientomnvar( "ui_armor_current_level", 0 );
    self armor::setarmorhealth( 0, 1, 1 );
    self armor::external_setarmorplates( 0 );
}

// -------------------- ARMOR WALL-BUY --------------------
function private is_armor_wall( wall )
{
    if ( !isdefined( wall ) )
    {
        return false;
    }
    if ( isdefined( wall.variant_type ) && ( wall.variant_type == "armor" || wall.variant_type == #"armor" ) )
    {
        return true;
    }
    return isdefined( wall.scriptablenamehash ) && wall.scriptablenamehash == #"wallbuy_zm_t10_armor_legendary";
}

function private on_armor_wall_spawned( params )
{
    if ( supported_mode() && is_armor_wall( self ) )
    {
        self bind_one_armor_wall();
    }
}

function private bind_armor_walls()
{
    level endon( #"game_ended" );
    while ( supported_mode() )
    {
        // Bind the game's existing armor-variant registration; do not create
        // replacement wallbuy entities or change scriptable part states.
        Wallbuy::register_wallbuy_variant_spawn( "armor", &purchase_armor, &armor_hint );
        if ( isdefined( level.interacts ) )
        {
            foreach ( wall in level.interacts )
            {
                if ( is_armor_wall( wall ) )
                {
                    wall bind_one_armor_wall();
                }
            }
        }
        wait 0.25;
    }
}

function private bind_one_armor_wall()
{
    self interaction::set_interact_use_callback( &purchase_armor );
    self interaction::set_interact_hint_callback( &armor_hint );
}

function private next_armor_tier( player )
{
    return minint( 4, ( player.platecarrierlevel ?? 0 ) + 1 );
}

function private armor_cost( tier )
{
    switch ( tier )
    {
        case 1: return 2500;
        case 2: return 4000;
        case 3: return 10000;
        case 4: return 25000;
    }
    return 25000;
}

function private purchase_armor( player )
{
    if ( !supported_mode() || !isplayer( player ) )
    {
        return;
    }
    if ( player.hasgoldenarmorplate )
    {
        return;
    }
    tier = next_armor_tier( player );
    cost = armor_cost( tier );
    if ( tier == 4 && !utility::issharedfuncdefined( #"zombie", #"set_golden_armor" ) )
    {
        return;
    }
    if ( !player currency::attempt_purchase( #"essence", cost, 1, undefined, #"wallbuy" ) )
    {
        player playsoundtoplayer( #"ui_zm_core_purchase_deny", player );
        return;
    }
    player.fresh_armor_bought_this_life = 1;
    if ( tier == 4 )
    {
        player utility::callsharedfunc( #"zombie", #"set_golden_armor" );
    }
    else
    {
        player zm_armor::give_armor( tier );
    }
    params = spawnstruct();
    params.cost = cost;
    params.armor_level = tier;
    params.currency = #"essence";
    player callback::callback( "wallbuy_armor_purchased", params );
    player playsoundtoplayer( #"ui_zm_core_purchase_success", player );
}

function private armor_hint( wall, player )
{
    if ( !supported_mode() || !isplayer( player ) )
    {
        return { #string:&"", #type:"HINT_NOBUTTON" };
    }
    tier = next_armor_tier( player );
    cost = armor_cost( tier );
    title = &"shared_hintstrings/armor_vest_lv1_pickup";
    description = &"cp_zmb/armor1_desc";
    switch ( tier )
    {
        case 2:
            title = &"shared_hintstrings/wallbuy_armor_hint_level_ii";
            description = &"cp_zmb/armor2_desc";
            break;
        case 3:
            title = &"shared_hintstrings/wallbuy_armor_hint_level_iii";
            description = &"cp_zmb/armor3_desc";
            break;
        case 4:
            title = &"shared_hintstrings/wallbuy_armor_hint_gold";
            if ( isdefined( level.var_c3cbabc25cac9c8e ) )
            {
                description = level.var_c3cbabc25cac9c8e.var_ecaed48dad41d0ff;
            }
            break;
    }
    hint = { #icon:"ui_icon_zm_ping_armor", #icon_text_value:cost, #icon_text:&"shared_hintstrings/cost_essence", #description:description, #title:title, #buttoncallout:&"shared_hintstrings/hint_buy", #params:[ cost, &"" ], #type:"HINT_BUTTON" };
    hint.string = title;
    if ( player.hasgoldenarmorplate )
    {
        hint.title = &"cp_zmb/armor_repair";
        hint.interactable = 0;
    }
    else if ( player currency::get_currency_amount( #"essence" ) < cost )
    {
        hint.aux_text = &"shared_hintstrings/not_enough_essence";
        hint.interactable = 0;
    }
    return hint;
}

// -------------------- MAP WONDER WEAPONS: AVAILABLE AT MATCH START --------------------
function private unlock_map_wonder_weapons()
{
    level endon( #"game_ended" );
    utility::flag_wait( "setup_magicbox_weapons" );
    utility::flag_wait( "magicbox_ready" );

    // Five map quests in this dump explicitly call function_2e49...(1)
    // to remove their map Wonder Weapon from the box until the quest ends.
    // The map's own wonderweaponitemspawnlist is already selected by BO7.
    level thread unlock_map_wonder_loop();
}

function private set_map_wonder_limit( item_name, limit )
{
    if ( !isdefined( level.a_magicbox_item_limits ) )
    {
        return;
    }
    if ( isdefined( level.a_magicbox_item_limits[ item_name ] ) &&
         level.a_magicbox_item_limits[ item_name ].itemmax < limit )
    {
        level.a_magicbox_item_limits[ item_name ].itemmax = limit;
    }
}

function private unlock_map_wonder_loop()
{
    level endon( #"game_ended" );
    b_rebuilt = 0;
    while ( supported_mode() )
    {
        // Restore the map's own Wonder Weapon list when quest scripts lock it.
        b_changed = 0;
        if ( isdefined( level.var_20cf5eda0c956d52 ) && level.var_20cf5eda0c956d52 )
        {
            magicbox::function_2e49cd8681e36211( 0 );
            b_changed = 1;
        }
        if ( isdefined( level.var_641b7c91f663ea4f ) && level.var_641b7c91f663ea4f )
        {
            magicbox::function_6f00dd035f2d8f9a( 0, 0 );
            b_changed = 1;
        }

        // These quest rewards have item limits raised only at quest completion.
        // Set the limit to the same completed-quest level from round 1.
        switch ( level.mapname )
        {
            case "zm_sat_firefly":
                set_map_wonder_limit( %"itemspawnentry:zm_sat_item_weapon_ww_firefly", 4 );
                break;
            case "zm_sat_hornet":
                set_map_wonder_limit( %"itemspawnentry:zm_sat_item_weapon_ww_hornet", 4 );
                break;
            case "zm_sat_locust":
                set_map_wonder_limit( %"itemspawnentry:zm_sat_item_weapon_ww_locust", 3 );
                break;
            case "zm_sat_scarab":
                set_map_wonder_limit( %"itemspawnentry:zm_sat_item_weapon_ww_scarab", 1 );
                break;
            case "zm_sat_ruby":
                set_map_wonder_limit( %"itemspawnentry:zm_sat_item_weapon_ww_ruby", 1 );
                break;
        }

        // Regenerate the roulette's cached map-weapon models after clearing
        // an initial quest lock. Not needed on subsequent unchanged frames.
        if ( ( !b_rebuilt || b_changed ) && isdefined( level.var_8b6bf63f61fe01f9 ) )
        {
            magicbox::function_b787d845dbbfa18e();
            b_rebuilt = 1;
        }
        wait 0.25;
    }
}

// =====================================================================
// STARTING WEAPON - PLAYER'S OWN SAVED 1911 ZOMBIE BUILD (rev. C)
// =====================================================================
// Verified in the BO7 dump:
//  - zm_rb_r_mod::post_main() (all three supported gametypes) calls
//    zm_mode_modifiers "set_no_starting_equipment" with weapon_override
//    "sat_pi_alcor_mp", which sets level.zm_mode_modifiers.var_a551bdc7e905a4fd.
//  - zombie_mode_modifiers::on_player_spawned() threads (on the player)
//    function_2bcdcde1ea4b896b() unless a saved round is loading. After
//    wait 1 it calls weapon_utility::makeweaponwithdefaults( override ),
//    which reaches weapon::makeweaponwithdefaults():
//        weaponobj = self [[ level.addbaseattachments ]]( weaponobj );
//    with self == the spawning player. It then does ONE giveweapon() and
//    ONE switchtoweapon() with whatever weapon that returned.
//  - level.addbaseattachments = zm::zm_add_base_attachments (zm.gsc).
//  - The Zombie Build is stock per-player data: weaponmetadata::
//    function_f5a4ca68b5d36e7e() runs on player_connect and fills
//    self.favoriteweapons[ "sat_pi_alcor_mp" ] from the player's
//    "zmFavoriteWeapons" stats (attachments, blueprint variant, camo,
//    reticle, charm, stickers). The 1911 entry is eligible (pistol,
//    canpap, not a wonder weapon) in zm_sat_weapons_list, which is the
//    gamemode bundle's list for these modes.
//  - weaponmetadata::function_c68204eff69ed046( name ) is the stock
//    "apply my Zombie Build" call: it returns the built weapon, or
//    undefined when the player has no build. Wall-buys (wallbuy.gsc),
//    the Mystery Box (magicbox.gsc), the weapon carousel modifier and
//    several quests all use it exactly this way.
// Approach: wrap level.addbaseattachments once. On spawn the player is
// armed for ONE swap; the first time the stock starting hand-out builds
// "sat_pi_alcor_mp" for that player, the wrapper returns the player's own
// Zombie Build instead. Stock code then gives it and switches to it
// itself: no second giveweapon, no takeweapon, no visible replacement.
// No build -> stock default 1911. Every other weapon, player, entity and
// call passes straight through to the original zm_add_base_attachments.

function private install_starting_1911_build_hook()
{
    level endon( #"game_ended" );

    // zm init assigns level.addbaseattachments; wait for it (bounded).
    for ( i = 0; i < 600 && !isdefined( level.addbaseattachments ); i++ )
    {
        waitframe();
    }
    if ( !try_hook_add_base_attachments() )
    {
        logstring( "[BO7 Cursed Fresh] level.addbaseattachments not found; 1911 Zombie Build not applied" );
    }
}

function private try_hook_add_base_attachments()
{
    if ( istrue( level.cursed_1911_build_hooked ) )
    {
        return 1;
    }
    if ( !isdefined( level.addbaseattachments ) )
    {
        return 0;
    }
    level.cursed_orig_addbaseattachments = level.addbaseattachments;
    level.addbaseattachments = &starting_1911_add_base_attachments;
    level.cursed_1911_build_hooked = 1;
    return 1;
}

// self = the player, from on_player_spawned().
function private arm_starting_1911_build()
{
    // Only when the stock starting hand-out will actually run.
    if ( !isdefined( level.zm_mode_modifiers ) || !istrue( level.zm_mode_modifiers.var_a551bdc7e905a4fd ) )
    {
        return;
    }
    if ( utility::issharedfuncdefined( #"zombie", #"is_loading_saved_round" ) && utility::callsharedfunc( #"zombie", #"is_loading_saved_round" ) )
    {
        return;
    }
    if ( !try_hook_add_base_attachments() )
    {
        return;
    }
    self.cursed_1911_build_pending = 1;
    self.cursed_knife_build_pending = 1; // v3: starting knife (melee_override)
    self thread expire_starting_1911_build();
}

// One-shot safety: if the stock hand-out is skipped (e.g. the healing-aura
// augment flag), disarm so no later 1911 is ever affected. Single wait, no loop.
function private expire_starting_1911_build()
{
    self notify( #"cursed_1911_build_expire" );
    self endon( #"cursed_1911_build_expire" );
    self endon( #"disconnect" );
    wait 5;
    self.cursed_1911_build_pending = undefined;
    self.cursed_knife_build_pending = undefined;
}

// Same calling convention as zm_add_base_attachments: self = caller's self.
function private starting_1911_add_base_attachments( weaponobj )
{
    if ( isdefined( self ) && isplayer( self ) && istrue( self.cursed_1911_build_pending ) && isweapon( weaponobj ) && weaponobj.basename == "sat_pi_alcor_mp" )
    {
        // Disarm FIRST: the stock build call below runs weapon::buildweapon(),
        // which re-enters this hook; that nested call must take the stock path
        // (it adds zm_add_base_attachments, keeping Pack-a-Punch compatibility).
        self.cursed_1911_build_pending = undefined;
        build = self weaponmetadata::function_c68204eff69ed046( "sat_pi_alcor_mp" );
        if ( isdefined( build ) && isweapon( build ) && !isnullweapon( build ) )
        {
            return build;
        }
        // No saved Zombie Build: fall through to the stock default 1911.
    }

    // v3: zm_rb_r_mod::post_main() sets melee_override "sat_me_knife_mp"; the
    // stock hand-out builds it with makeweaponwithdefaults() (this hook), then
    // giveweapon() + weapon::updatetertiaryweapon(). sat_me_knife_mp is an
    // eligible melee entry in zm_sat_weapons_list, so the player's saved build
    // is in self.favoriteweapons. Separate flag: independent from the 1911.
    if ( isdefined( self ) && isplayer( self ) && istrue( self.cursed_knife_build_pending ) && isweapon( weaponobj ) && weaponobj.basename == "sat_me_knife_mp" )
    {
        self.cursed_knife_build_pending = undefined;
        build = self weaponmetadata::function_c68204eff69ed046( "sat_me_knife_mp" );
        if ( isdefined( build ) && isweapon( build ) && !isnullweapon( build ) )
        {
            return build;
        }
        // No saved Knife Zombie Build: stock default knife.
    }

    orig = level.cursed_orig_addbaseattachments;
    if ( isfunction( orig ) )
    {
        return self [[ orig ]]( weaponobj );
    }
    return weaponobj;
}

// =====================================================================
// NEW: ZOMBIE ATTACK DAMAGE - ROUNDS 1-10 USE THE ROUND-11 TIER
// =====================================================================
// Verified in the BO7 dump:
//  - damage_scaling_round::init_scaling_damage() registers
//    sharedfunc( #"zombie", #"hash_e27e55920dabe660" ) =
//    function_c0f17eb03e09d5ef( fixed_round_number ).
//  - It is called per AI at spawn (zombie_init.gsc, zm_round_spawning.gsc)
//    with the AI's difficulty round, and reads the AI's own
//    "damagescalinground:" bundle: melee / ranged / leap / armor-health /
//    custom damage multipliers, all "startround -> damagemultiplier".
//  - The common zombie tables are 1:x1.0, 11:x1.6666, 31:x2.5, ... (cap 250).
//    Health uses a different sharedfunc, so this hook cannot touch health.
// Approach: wrap the stock function and, for rounds 1-10 only, run it with
// round 11. Every AI keeps ITS OWN table (so a type whose tier only changes
// at 21 is correctly unchanged) and caps stay intact. Rounds 11+ call the
// original with the original round number. Player-side reductions (armor,
// Juggernog, augments) are applied later in the damage pipeline and are not
// affected. Exfil passes round 1 on purpose; the live-round check keeps that.

function private install_early_round_damage_tier()
{
    level endon( #"game_ended" );

    // zm init registers the stock function; wait for it (bounded).
    for ( i = 0; i < 600 && !utility::issharedfuncdefined( #"zombie", #"hash_e27e55920dabe660" ); i++ )
    {
        waitframe();
    }
    if ( !utility::issharedfuncdefined( #"zombie", #"hash_e27e55920dabe660" ) )
    {
        logstring( "[BO7 Cursed Fresh] Zombie damage scaling func not found; early-round tier not applied" );
        return;
    }
    if ( istrue( level.cursed_damage_tier_hooked ) )
    {
        return;
    }
    level.cursed_orig_damage_scaling = utility::getsharedfunc( #"zombie", #"hash_e27e55920dabe660" );
    utility::registersharedfunc( #"zombie", #"hash_e27e55920dabe660", &early_round_damage_tier );
    level.cursed_damage_tier_hooked = 1;
}

// self = the AI being scaled (same calling convention as the stock function).
function private early_round_damage_tier( fixed_round_number )
{
    orig = level.cursed_orig_damage_scaling;
    if ( !isfunction( orig ) )
    {
        return;
    }

    if ( !supported_mode() || !isdefined( fixed_round_number ) || fixed_round_number < 1 || fixed_round_number >= 11 || zm_utility::get_round_number() >= 11 )
    {
        return self [[ orig ]]( fixed_round_number );
    }

    // First pass at the real round, only to keep the max-simultaneous-target
    // count (var_577dec43cf1caedf, a targeting value, not damage) unchanged.
    // The stock function is idempotent (recomputes from *_base values).
    self [[ orig ]]( fixed_round_number );
    max_targets = self.var_577dec43cf1caedf;

    // Second pass with round 11 sets all damage values to the round-11 tier.
    self [[ orig ]]( 11 );
    self.var_577dec43cf1caedf = max_targets;
}

// =====================================================================
// NEW: START WITH 0 GOBBLEGUMS (WAS 3)
// =====================================================================
// Verified in the BO7 dump (script_aa3bac81ad4fc8e, #namespace bgb):
//  - bgb::on_player_connect() -> bgb_player_init() builds the player's
//    5-gum pack (self.bgb_pack) and, when dvar hash_a7dd6191064a0709 (default
//    1) is set and there is no saved loadout, pre-loads the first 3 into the
//    3 action slots (self.bgb_action_pack[1..3]) via function_c068e36660508e7c.
//    THOSE are the "3 starting GobbleGums": loaded slots, not charges and not
//    inventory. Pre-loading consumes nothing; use is counted on activation.
//  - The GobbleGum machine (bgb_machine) only works when an action slot is
//    open (bgb::get_open_action_slot()) and draws from self.bgb_pack.
//  - During the first 180s, changing pack in-game re-fills the 3 slots via
//    function_9e1a713b9554d08a only while self.allow_instant_bgb_pack_switching
//    is 1 (stock sets it to 0 after the first gum use or 180s).
// Approach: once, right after stock connect-init, empty the pre-loaded slots
// with the stock bgb::clear_action_slot() and close the instant re-fill.
// The pack, inventory counts and the machine are untouched, so gums can be
// earned normally. Nothing runs on respawn. Saved-round loads are skipped.

function private on_player_connect_gobblegums( params )
{
    if ( !supported_mode() || !isplayer( self ) )
    {
        return;
    }
    self thread clear_starting_gobblegums();
}

function private clear_starting_gobblegums()
{
    self endon( #"disconnect" );
    level endon( #"game_ended" );

    // bgb_player_init() runs synchronously in bgb's own player_connect
    // callback; let every connect callback finish first.
    waittillframeend();
    for ( i = 0; i < 20 && !isdefined( self.bgb_action_pack ); i++ )
    {
        waitframe();
    }
    if ( !isdefined( self.bgb_action_pack ) )
    {
        return; // GobbleGums disabled for this match.
    }
    if ( istrue( self.cursed_starting_gums_cleared ) )
    {
        return;
    }
    self.cursed_starting_gums_cleared = 1;

    // Same saved-loadout checks stock uses; restored gums are legitimate.
    if ( utility::issharedfuncdefined( #"zombie", #"is_loading_saved_round" ) && utility::callsharedfunc( #"zombie", #"is_loading_saved_round" ) )
    {
        return;
    }
    if ( utility::issharedfuncdefined( #"zombie", #"has_saved_loadout" ) && utility::callsharedfunc( #"zombie", #"has_saved_loadout" ) )
    {
        return;
    }

    // Stop the pre-match pack switch from re-filling all 3 slots.
    self.allow_instant_bgb_pack_switching = 0;

    for ( slot = 1; slot <= 3; slot++ )
    {
        if ( self bgb::is_slot_loaded( slot ) && !istrue( self.is_using_bgb_slot[ slot ] ) )
        {
            self bgb::clear_action_slot( slot );
        }
    }
}

// =====================================================================
// rev. D: CLASSIC BO1 M1911 - WHITE 1911 DAMAGE BY HIT LOCATION
// =====================================================================
// Verified in the BO7 dump:
//  - zm_damage::zombie_agent_damage_callback() (and br_damage's copy) run the
//    stock zombie damage pipeline: rarity / PaP / critical multipliers first
//    (zombie_damage::function_881dfa87252ee0ea), then augments and relics,
//    then zombie_damage::function_23f0f83c55de1ad(), which calls the
//    per-weapon callback stored by zombie_utils::
//    register_zombie_weapon_damage_callback( weapon_name, func ), keyed by
//    sweapon.basename. A callback returning >= 0 sets the damage; -1 leaves
//    it untouched. No stock script registers one for "sat_pi_alcor_mp".
//  - After that callback, zombie_damage::function_960f65c8626d199b() divides
//    head / neck / helmet damage by the weapon asset's head modifier unless
//    dmg_struct.bskipexposedhead is set (stock flag, set the same way in
//    zombie_weyward.gsc and several map scripts). It is set here for head
//    hits so the value below is the final headshot damage.
//  - The 1911's raw damage, location multipliers and the knife's damage live
//    in the weapon assets, not in the script dump. Attachments in a player's
//    Zombie Build (barrels, .45 FMJ ammo, ...) can change that raw damage.
//    So the damage is SET here to an absolute value instead of scaled,
//    which makes it identical for every Zombie Build and every range.
//  - Normal zombie = subclass "zombie_base", aicategory "normal".
//    Spawn health = health_scaling_get_starting_health( own healthscriptbundle,
//    round ) called on the zombie (zombie_init.gsc); round 1 = base health.
//    The ZM normal-zombie bundles have numplayerhealthscale 0 (no co-op HP).
//  - Cursed classic points (zombie_mode_modifiers::set_classic_points):
//    10 per hit that does not kill (and while total damage <= maxhealth),
//    130 for a MOD_MELEE kill. 8 x 10 + 130 = 210 is the stock scoring.
// Base value (legs / feet / arms / hands) = floor( ( round-1 health - 1 ) / 8 ):
//    8 leg hits <= health - 1 -> the zombie always survives all 8 shots;
//    remaining health after 8 hits is 1..8 HP -> one knife hit kills.
// Other locations use BO1 Zombies M1911 multipliers on that base value
// (BO1: 20 damage; head x3.5, chest x1.25, abdomen x1.1, limbs x1.0):
//    torso_upper (chest) x1.25, torso_lower (abdomen) x1.1,
//    head / neck / helmet x3.5 (BO7 treats these three as one head zone).
// The values are flat for the whole match (BO1-style: fixed pistol damage,
// zombie health keeps growing). Other rarities, Pack-a-Punched 1911s, other
// weapons, other enemies, melee and unknown hit locations stay stock.

function private classic_1911_location_mult( loc )
{
    if ( !isdefined( loc ) )
    {
        return undefined;
    }
    if ( loc == "head" || loc == "neck" || loc == "helmet" )
    {
        return 3.5;
    }
    if ( issubstr( loc, "torso_upper" ) )
    {
        return 1.25;
    }
    if ( issubstr( loc, "torso_lower" ) )
    {
        return 1.1;
    }
    if ( issubstr( loc, "leg" ) || issubstr( loc, "foot" ) || issubstr( loc, "arm" ) || issubstr( loc, "hand" ) )
    {
        return 1.0;
    }
    return undefined; // "none", "gun", "shield", "armor", ... -> stock damage
}

function private classic_1911_leg_damage( dmg_struct )
{
    // self = the zombie being damaged.
    if ( !supported_mode() )
    {
        return -1;
    }
    attacker = dmg_struct.eattacker;
    if ( !isdefined( attacker ) || !isplayer( attacker ) )
    {
        return -1;
    }
    if ( !isdefined( self.subclass ) || self.subclass != "zombie_base" || !isdefined( self.aicategory ) || self.aicategory != "normal" )
    {
        return -1;
    }
    if ( !isdefined( dmg_struct.smeansofdeath ) || !utility::isbulletdamage( dmg_struct.smeansofdeath ) )
    {
        return -1; // pistol-whip / melee / explosive / ammo-mod damage stays stock
    }
    loc = dmg_struct.shitloc;
    mult = classic_1911_location_mult( loc );
    if ( !isdefined( mult ) )
    {
        return -1;
    }
    w = dmg_struct.objweapon;
    if ( !isdefined( w ) || !isweapon( w ) || w.basename != "sat_pi_alcor_mp" )
    {
        return -1;
    }

    // White / Common only (stock get_rarity(): undefined or 0 == "white").
    if ( utility::issharedfuncdefined( #"zombie", #"getplayerweaponrarity" ) )
    {
        rarity = attacker utility::callsharedfunc( #"zombie", #"getplayerweaponrarity", w );
        if ( isdefined( rarity ) && rarity != 0 )
        {
            return -1;
        }
    }
    // Not Pack-a-Punched.
    if ( attacker pack_a_punch::get_pap_level( w ) > 0 )
    {
        return -1;
    }

    // Round-1 health of THIS zombie type, from the stock health system.
    if ( !isdefined( self.zombieaisettings ) || !isdefined( self.zombieaisettings.healthscriptbundle ) )
    {
        return -1;
    }
    round1_health = self shared_func_utility::function_bb9b98eb7368a15a( self.zombieaisettings.healthscriptbundle, 1 );
    if ( !isdefined( round1_health ) || int( round1_health ) < 9 )
    {
        return -1;
    }
    base = int( ( int( round1_health ) - 1 ) / 8 );

    if ( loc == "head" || loc == "neck" || loc == "helmet" )
    {
        // Our value is final: stop the stock exposed-head step from dividing it.
        dmg_struct.bskipexposedhead = 1;
    }
    return int( base * mult );
}

// =====================================================================
// v3: WEAPON PROGRESSION OVERHAUL
// =====================================================================

// ---------- 1. PACK-A-PUNCH LEVEL -> RARITY ----------
// Verified in the BO7 dump:
//  - Cursed's gametype bundle has the item-based PaP flag off, so every PaP
//    (stock menu purchase and this mod's Tier IV fallback) goes through
//    pack_a_punch::pap_weapon(), which fires
//    callback::callback( "zm_packed_weapon", params ) with params.player /
//    params.w_new, then gives w_new and calls set_pap_level() in the same frame.
//  - Rarity is stored per primary-inventory slot (item_weapon weapon data,
//    matched by basename), so it survives the PaP weapon swap.
//  - The native rarity setter is item_weapon::function_40e1cbd0e1f47d1a(
//    weapon, rarity ) - the exact call arsenal::upgrade_rarity() makes. It
//    updates the rarity read by zombie_damage::get_rarity() (damage), the
//    rarity HUD, and fires "on_weapon_rarity_set_complete".
//  - Rarity indices: 0 white, 1 green, 2 blue, 3 purple, 4 legendary,
//    5 "ultra_red" (magicbox::function_c19ee905418ebc92).
//  - arsenal::can_increase_weapon_tier() rejects fists, killstreaks and
//    Wonder Weapons; it is reused here unchanged.
// PaP I -> blue (2), II -> purple (3), III -> legendary (4), IV -> ultra (5).
// Never lowers rarity, never re-applies, costs nothing extra.

// Fired by pack_a_punch::pap_weapon() (direct PaP) and, for the PaP where
// the weapon floats out of the machine (function_893799cfb3f4d2d7), again by
// function_fc8ec85501be6cb8() when the player picks the packed weapon up -
// that pickup restores the OLD rarity from the stored item info, which is why
// rarity must be re-applied after it. self = the player in both cases.
function private on_packed_weapon_rarity( params )
{
    player = self;
    if ( isdefined( params ) && isdefined( params.player ) )
    {
        player = params.player;
    }
    if ( !supported_mode() || !isdefined( player ) || !isplayer( player ) )
    {
        return;
    }
    player thread reconcile_pap_rarity_deferred();
}

// weapons.gsc watchchangeweapon(): self = player. Also covers any other
// path that hands back a packed weapon. Event-driven, no polling.
function private on_weapon_change_rarity( params )
{
    if ( supported_mode() && isplayer( self ) )
    {
        self thread reconcile_pap_rarity_deferred();
    }
}

function private reconcile_pap_rarity_deferred()
{
    self endon( #"disconnect" );
    // Let the stock PaP / pickup code finish its give + set_pap_level() first.
    waittillframeend();
    self reconcile_pap_rarity();
}

// Rarity follows the PaP level of every primary weapon (upward only).
function private reconcile_pap_rarity()
{
    foreach ( w in self getweaponslistprimaries() )
    {
        if ( !isweapon( w ) || isnullweapon( w ) || !can_change_weapon_tier( w ) )
        {
            continue;
        }
        pap_level = self pack_a_punch::get_pap_level( w );
        if ( !isdefined( pap_level ) || pap_level <= 0 )
        {
            continue;
        }
        target = pap_level_rarity( w, pap_level );
        if ( target <= 0 )
        {
            continue;
        }
        current = self get_weapon_rarity( w );
        if ( isdefined( current ) && current >= target )
        {
            continue;
        }
        self set_weapon_rarity( w, target );
    }
}

// Same rule as arsenal::can_increase_weapon_tier() (fists, killstreaks and
// Wonder Weapons cannot change tier), written out here so this script does
// not call into the arsenal namespace.
function private can_change_weapon_tier( w )
{
    return !( weapon::isfistweapon( w ) || weapon::iskillstreakweapon( w ) || weapon::iswonderweapon( w ) );
}

// Stock rarity getter: shared func registered by item_weapon
// (#"zombie", #"getplayerweaponrarity" -> function_fb81bd2fe070faa6).
function private get_weapon_rarity( w )
{
    if ( utility::issharedfuncdefined( #"zombie", #"getplayerweaponrarity" ) )
    {
        return utility::callsharedfunc( #"zombie", #"getplayerweaponrarity", w ) ?? 0;
    }
    return item_weapon::function_fb81bd2fe070faa6( w );
}

// Stock rarity setter: shared func registered by item_weapon
// (#"zombie", #"hash_e546039029657cd5" -> function_40e1cbd0e1f47d1a).
function private set_weapon_rarity( w, rarity )
{
    if ( utility::issharedfuncdefined( #"zombie", #"hash_e546039029657cd5" ) )
    {
        utility::callsharedfunc( #"zombie", #"hash_e546039029657cd5", w, rarity );
        return;
    }
    item_weapon::function_40e1cbd0e1f47d1a( w, rarity );
}

function private pap_level_rarity( w, pap_level )
{
    switch ( pap_level )
    {
        case 1: return 2;
        case 2: return 3;
        case 3: return 4;
        case 4:
            // The zm_sat weapon list defines no base Ultra damage multiplier;
            // Ultra damage then depends on the weapon asset's own value. Use
            // the game's own multiplier lookup and never trade Legendary for a
            // weaker Ultra. (get_rarity() names index 4 "orange", 5 "yellow".)
            legendary = zombie_damage::function_6786d0923b8261db( w, "MOD_RIFLE_BULLET", "orange" );
            ultra = zombie_damage::function_6786d0923b8261db( w, "MOD_RIFLE_BULLET", "yellow" );
            if ( isdefined( legendary ) && isdefined( ultra ) && ultra < legendary )
            {
                logstring( "[BO7 Cursed Fresh] Ultra multiplier below Legendary for this weapon; keeping Legendary at PaP IV" );
                return 4;
            }
            return 5;
    }
    return 0;
}

// ---------- 2. ARSENAL: RANDOM AMMO MOD FOR 250 SALVAGE ----------
// Verified in the BO7 dump (mp/arsenal.gsc, mp/ammomods/ammo_mod.gsc):
//  - init_arsenal_machine() registers each machine's interact with
//    on_use_arsenal / arsenal_per_player_hint, stores interact.s_arsenal and
//    then fires callback::callback( #"on_arsenal_spawned" ) on the machine.
//  - The stock ammo-mod purchase (craft_weapon_ammomod) checks can_afford,
//    rejects the mod already on the weapon, requires
//    ammo_mod::can_get_ammo_mod(), applies ammo_mod::add_ammo_mod_to_weapon(),
//    fires "arsenal_craft_ammo_mod", then sub_currency_amount(). Applying a
//    new mod natively REPLACES the current one (add_ammo_mod_to_weapon).
//  - The Arsenal menu content comes from purchase-menu bundles that script
//    cannot edit, so the machine's interaction is rebound instead (same
//    interaction API this mod already uses for armor walls). The menu - and
//    with it manual rarity upgrades - is no longer opened.
//  - level.arsenal_max_weapon_rarity = 0 additionally makes the stock
//    craft_weapon_tier() refuse (response 4, no charge) if the menu is
//    ever opened by any other path.

function private on_arsenal_spawned_bind( params )
{
    if ( supported_mode() )
    {
        self arsenal_bind_one();
    }
}

// self = arsenal struct (level.a_s_arsenal_locations entry)
function private arsenal_bind_one()
{
    if ( !isdefined( self.mdl_arsenal ) || !isdefined( self.mdl_arsenal.interact ) )
    {
        return;
    }
    self.mdl_arsenal.interact interaction::set_interact_use_callback( &arsenal_random_ammo_mod_use );
    self.mdl_arsenal.interact interaction::set_interact_hint_callback( &arsenal_random_ammo_mod_hint );
}

// self = player. The weapon the Arsenal should modify. At the moment Use is
// pressed getcurrentweapon() can be the interact gesture / hands rather than
// the gun, so the held primary is preferred (engine builtins used by stock:
// getcurrentweapon, getcurrentprimaryweapon).
// A real weapon in hand (not "none" / fists).
function private arsenal_is_real_weapon( w )
{
    return isdefined( w ) && isweapon( w ) && !isnullweapon( w ) && !weapon::isfistweapon( w );
}

// Wonder Weapons never take Arsenal mods. ammo_mod::can_get_ammo_mod()
// only checks weapon::iswonderweapon() (metadata iswonderweapon flag); map
// Wonder Weapons are also flagged ismapwonderweapon, and their weapons are
// named sat_ww_*, so all three are rejected here.
function private arsenal_is_wonder_weapon( w )
{
    if ( weapon::iswonderweapon( w ) || weapon::ismapwonderweapon( w ) )
    {
        return true;
    }
    return isdefined( w.basename ) && issubstr( w.basename, "_ww_" );
}

function private arsenal_weapon_ok( w )
{
    return self arsenal_is_real_weapon( w ) && self hasweapon( w ) && !arsenal_is_wonder_weapon( w ) && ammo_mod::can_get_ammo_mod( w );
}

// The weapon the Arsenal acts on is ALWAYS the one in hand. Only when the gun
// is lowered by the machine itself (getcurrentweapon / getcurrentprimaryweapon
// = "none" at the moment of the press) is the weapon the hint last saw in
// hand used instead - even when that weapon cannot take a mod, so a held
// Wonder Weapon is refused rather than another gun being modified.
function private arsenal_held_weapon()
{
    w = self getcurrentweapon();
    if ( self arsenal_is_real_weapon( w ) )
    {
        return w;
    }
    w = self getcurrentprimaryweapon();
    if ( self arsenal_is_real_weapon( w ) )
    {
        return w;
    }
    return undefined;
}

function private arsenal_is_primary( w )
{
    if ( !isdefined( w ) )
    {
        return false;
    }
    foreach ( pw in self getweaponslistprimaries() )
    {
        if ( pw == w )
        {
            return true;
        }
    }
    return false;
}

// Order: the gun in hand -> the primary the hint last saw in hand -> the
// last primary weapons.gsc recorded (self.lastweaponobj). The fallbacks are
// used AS-IS (not skipped when unsuitable), so a held Wonder Weapon is
// refused instead of another gun being picked. Non-primary entries (use
// gesture / hands) are skipped.
function private arsenal_target_weapon()
{
    held = self arsenal_held_weapon();
    if ( isdefined( held ) )
    {
        return held;
    }
    if ( isdefined( self.cursed_arsenal_weapon ) && self arsenal_is_primary( self.cursed_arsenal_weapon ) )
    {
        return self.cursed_arsenal_weapon;
    }
    if ( isdefined( self.lastweaponobj ) && self arsenal_is_primary( self.lastweaponobj ) )
    {
        return self.lastweaponobj;
    }
    return self getcurrentweapon();
}

// self = player. Returns a random valid mod different from the current one.
function private arsenal_pick_ammo_mod( weapon )
{
    // self.cursed_arsenal_fail names the exact check that failed (shown on
    // screen by the purchase), so a refusal can be traced to one cause.
    self.cursed_arsenal_fail = undefined;
    if ( !istrue( level.ammo_mods_in_use ) || !isdefined( level.ammo_mods ) )
    {
        self.cursed_arsenal_fail = "Arsenal: Ammo Mods are not enabled in this mode";
        return undefined;
    }
    if ( !isdefined( weapon ) || !isweapon( weapon ) || isnullweapon( weapon ) )
    {
        self.cursed_arsenal_fail = "Arsenal: no weapon in hand";
        return undefined;
    }
    if ( weapon::isfistweapon( weapon ) )
    {
        self.cursed_arsenal_fail = "Arsenal: hands/fists cannot take Ammo Mods";
        return undefined;
    }
    if ( arsenal_is_wonder_weapon( weapon ) || !ammo_mod::can_get_ammo_mod( weapon ) )
    {
        self.cursed_arsenal_fail = "Arsenal: this weapon cannot take Ammo Mods";
        return undefined;
    }

    current = ammo_mod::get_ammo_mod_name( weapon );
    pool = [];
    // 1) The stock random pool (what ammo_mod::get_random_ammo_mod() uses).
    if ( isdefined( level.ammomodsbundlelist ) && isdefined( level.ammomodsbundlelist.ammomodbundles ) )
    {
        foreach ( bundle in level.ammomodsbundlelist.ammomodbundles )
        {
            name = bundle.ammomodname;
            if ( isdefined( name ) && isdefined( level.ammo_mods[ name ] ) && !( name === current ) && !( name === "none" ) )
            {
                pool[ pool.size ] = name;
            }
        }
    }
    // 2) Fallback: every Ammo Mod registered with ammo_mod::register_ammo_mod()
    //    (the table add_ammo_mod_to_weapon() itself reads), minus "none".
    if ( !pool.size )
    {
        foreach ( name in getarraykeys( level.ammo_mods ) )
        {
            if ( isdefined( name ) && !( name === "none" ) && !( name === current ) )
            {
                pool[ pool.size ] = name;
            }
        }
    }
    if ( !pool.size )
    {
        self.cursed_arsenal_fail = "Arsenal: no other Ammo Mod available";
        return undefined;
    }
    return utility::array_random( pool );
}

// self = arsenal interact
// Finds the arsenal struct for this interact; falls back to the machine
// nearest the player if the use arrives on another handle.
function private arsenal_struct_for_use( player )
{
    if ( isdefined( self ) && isdefined( self.s_arsenal ) )
    {
        return self.s_arsenal;
    }
    best = undefined;
    if ( isdefined( level.a_s_arsenal_locations ) )
    {
        foreach ( s in level.a_s_arsenal_locations )
        {
            if ( !isdefined( s.mdl_arsenal ) )
            {
                continue;
            }
            if ( !isdefined( best ) || distancesquared( s.mdl_arsenal.origin, player.origin ) < distancesquared( best.mdl_arsenal.origin, player.origin ) )
            {
                best = s;
            }
        }
    }
    return best;
}

// self = arsenal interact. Every refusal plays the deny sound AND prints the
// reason, so a failing purchase is never silent.
function private arsenal_random_ammo_mod_use( player )
{
    if ( !supported_mode() || !isplayer( player ) )
    {
        return;
    }
    if ( !self arsenal_in_reduced_range( player ) )
    {
        return; // outside the reduced prompt range: no prompt, no purchase
    }
    s_arsenal = self arsenal_struct_for_use( player );
    if ( !isdefined( s_arsenal ) )
    {
        arsenal_refuse( player, "Arsenal: machine not found" );
        return;
    }
    // Same checks as arsenal::can_use_arsenal().
    if ( !istrue( s_arsenal.b_arsenal_enabled ) )
    {
        arsenal_refuse( player, "Arsenal: no power" );
        return;
    }
    if ( istrue( player.interactions_disabled ) || istrue( player.arsenal_disabled ) )
    {
        return;
    }
    cost = 250;
    weapon = player arsenal_target_weapon();
    // One-time bounded wait (max 1 s) for the gun to come back up.
    for ( i = 0; i < 20 && !player arsenal_weapon_ok( weapon ); i++ )
    {
        waitframe();
        if ( !isdefined( player ) )
        {
            return;
        }
        weapon = player arsenal_target_weapon();
    }
    mod = player arsenal_pick_ammo_mod( weapon );
    if ( !isdefined( mod ) )
    {
        arsenal_refuse( player, player.cursed_arsenal_fail ?? "Arsenal: this weapon cannot take Ammo Mods" );
        return;
    }
    if ( !player currency::can_afford( #"salvage", cost ) )
    {
        arsenal_refuse( player, "Arsenal: not enough Salvage" );
        return;
    }

    // Native apply (replaces an existing mod, same as the stock Arsenal).
    new_weapon = player ammo_mod::add_ammo_mod_to_weapon( weapon, mod );
    applied = 0;
    if ( isdefined( new_weapon ) && isweapon( new_weapon ) && player ammo_mod::has_ammo_mod_by_name( new_weapon, mod ) )
    {
        applied = 1;
    }
    else if ( player ammo_mod::get_ammo_mod_name( weapon ) == mod )
    {
        applied = 1;
    }
    if ( !applied )
    {
        arsenal_refuse( player, "Arsenal: Ammo Mod could not be applied (no charge)" );
        return;
    }

    params = spawnstruct();
    params.item = mod;
    params.currency = #"salvage";
    params.cost = cost;
    player callback::callback( "arsenal_craft_ammo_mod", params );
    player currency::sub_currency_amount( #"salvage", cost );

    player playsoundtoplayer( #"ui_zm_core_purchase_success", player );
    if ( isdefined( s_arsenal.mdl_arsenal ) )
    {
        s_arsenal.mdl_arsenal setscriptablepartstate( "anim", "weapon_upgrade" );
        s_arsenal.mdl_arsenal setscriptablepartstate( "audio_purchase", "ammomod" );
    }
}

function private arsenal_refuse( player, msg )
{
    player playsoundtoplayer( #"ui_zm_core_purchase_deny", player );
    player iprintlnbold( msg );
}

function private arsenal_random_ammo_mod_hint( usable, player )
{
    if ( !supported_mode() || !isplayer( player ) || !isdefined( usable ) || !isdefined( usable.s_arsenal ) )
    {
        return { #string:&"", #type:"HINT_BUTTON" };
    }
    if ( !usable arsenal_in_reduced_range( player ) )
    {
        return { #string:&"", #type:"HINT_NOICON" }; // prompt hidden (as stock does)
    }
    cost = 250;
    hint = { #icon:"ui_icon_zm_ping_arsenal", #icon_text_value:cost, #icon_text:&"shared_hintstrings/cost_salvage", #title:&"shared_hintstrings/arsenal_title", #buttoncallout:&"shared_hintstrings/hint_buy", #params:[ cost, &"" ], #type:"HINT_BUTTON" };
    hint.string = hint.title;
    if ( !istrue( usable.s_arsenal.b_arsenal_enabled ) )
    {
        hint.aux_text = usable.arsenalpowerstringoverride ?? &"shared_hintstrings/need_power_red";
        hint.interactable = 0;
        return hint;
    }
    if ( player.interactions_disabled || player.arsenal_disabled )
    {
        return { #string:&"", #type:"HINT_NOICON" };
    }
    player arsenal_prompt_label_touch( usable );
    hint_weapon = player arsenal_target_weapon();
    held = player arsenal_held_weapon();
    if ( isdefined( held ) && player arsenal_is_primary( held ) )
    {
        player.cursed_arsenal_weapon = held; // whatever is in hand, valid or not
    }
    if ( !isdefined( player arsenal_pick_ammo_mod( hint_weapon ) ) )
    {
        hint.aux_text = &"ZM_RB_ECHO/PORTAL_AMMO_MOD_WONDER_WEAPON";
        hint.interactable = 0;
    }
    else if ( !player currency::can_afford( #"salvage", cost ) )
    {
        hint.aux_text = &"shared_hintstrings/not_enough_salvage";
        hint.interactable = 0;
    }
    return hint;
}

// ---------- 3. WALL-BUYS: PERMANENTLY GREEN ----------
// Verified in mp/wallbuy.gsc:
//  - Weapon walls are level.contentmanager.spawnedinstances[ "wallbuy" ]
//    [ i ].contentgroups[ "wallbuy_spawn" ][ j ].wallbuy_scriptable with
//    .weapon_root_name (variant walls such as armor have none).
//  - Wallbuy::on_round_end() raises rarity every 5 rounds through
//    update_wallbuy_rarity(), which returns early when
//    wallbuy_scriptable.disable_upgrade is set.
//  - Purchases build the item from wallbuy_scriptable.rarity (item entry
//    "_green", and favourite-build rarity via rarity_to_number), so the
//    bought weapon's real rarity matches the wall.
// Set exactly what update_wallbuy_rarity() sets (rarity, cost from the
// stock get_wallbuy_cost(), "wallbuy" part state), without its upgrade fx,
// and set disable_upgrade so rounds and stock scripts cannot raise it.

function private lock_wallbuys_green_init()
{
    level endon( #"game_ended" );
    utility::flag_wait( "wallbuy_ready" );
    lock_wallbuys_green();
}

function private on_round_end_lock_wallbuys( params )
{
    if ( supported_mode() )
    {
        lock_wallbuys_green(); // catches any wall spawned after the first pass
    }
}

function private lock_wallbuys_green()
{
    if ( !isdefined( level.contentmanager ) || !isdefined( level.contentmanager.spawnedinstances[ "wallbuy" ] ) )
    {
        return;
    }
    foreach ( instance in level.contentmanager.spawnedinstances[ "wallbuy" ] )
    {
        if ( !isdefined( instance.contentgroups ) || !isdefined( instance.contentgroups[ "wallbuy_spawn" ] ) )
        {
            continue;
        }
        foreach ( wallbuy_spawn in instance.contentgroups[ "wallbuy_spawn" ] )
        {
            ws = wallbuy_spawn.wallbuy_scriptable;
            if ( !isdefined( ws ) || !isdefined( ws.weapon_root_name ) || is_armor_wall( ws ) )
            {
                continue;
            }
            if ( !( ws.rarity === "green" ) )
            {
                ws.rarity = "green";
                ws.cost = Wallbuy::get_wallbuy_cost( ws.weapon_root_name, "green" );
                ws setscriptablepartstate( "wallbuy", "green" );
            }
            ws.disable_upgrade = 1;
        }
    }
}

// ---------- 4. MYSTERY BOX: GREEN REGULAR WEAPONS, NO AETHER TOOLS ----------
// Verified in mp/magicbox.gsc setup_magicbox_weapon_array() and the box
// bundles:
//  - Each roll reads the round entry of level.s_magicbox_scaling.
//    magicboxroundscale. Regular-weapon rarity is decided by n_roll against
//    checks built from legendarychance / epicchance / rarechance; a weapon
//    re-rolled from a high roll (e.g. a Wonder Weapon you already own) lands
//    above every check and becomes Legendary.
//  - The misc list (miscitemspawnlist hash_1d887968b1d9d406) contains ONLY
//    itemspawnentry:zm_t10_item_aether_tool.
//  - Legacy weapons (legacyweaponchance of the active scaling bundle; the
//    map can override the bundle, so this applies in all three modes) are in
//    level.var_d46bd3e7f2f3e08e and take the item's own Ultra rarity branch,
//    not the regular-weapon rarity checks - left exactly as stock (v3.14).
//  - The roulette preview rolls percent_chance() on the same three values.
// Applied once to every round entry: rare/epic 0, legendary -100 (all three
// checks end above 100, so every regular weapon - rolled, re-rolled and
// previewed - is Green), misc 0 (no Aether Tools; its share goes back to the
// regular weapon list). legacyweaponchance is left as stock.
// ultrachance (Wonder Weapons), support and equipment are untouched.

function private lock_magicbox_green()
{
    level endon( #"game_ended" );
    utility::flag_wait( "setup_magicbox_weapons" );
    utility::flag_wait( "magicbox_ready" );
    if ( !isdefined( level.s_magicbox_scaling ) || !isdefined( level.s_magicbox_scaling.magicboxroundscale ) )
    {
        return;
    }
    foreach ( s_scale in level.s_magicbox_scaling.magicboxroundscale )
    {
        s_scale.rarechance = 0;
        s_scale.epicchance = 0;
        s_scale.legendarychance = -100;
        s_scale.miscchance = 0;
    }
}

// ---------- v3.9: ARSENAL PROMPT TEXT FOR LUA ----------
// zm_cursed_arsenal_prompt_post.lua shows dvar cursed_arsenal_prompt inside
// the Arsenal prompt (same pattern as zm_perk_remove_post.lua: GSC setdvar()
// -> Lua Dvar.GetDvarString()). The dvar is global, so the local (first)
// player drives it. Bounded watcher: runs only while that player stays at
// the machine, then clears the text and ends.
// Same pattern as the working perk-remove script (set_prompt_text /
// prompt_text_watch): every hint call refreshes a timestamp; the dvar is only
// written when the text changes; one level watcher clears it 250 ms after the
// hint calls stop (prompt gone).
function private arsenal_prompt_label_touch( usable )
{
    if ( !isdefined( level.players ) || !level.players.size || self != level.players[ 0 ] || !isdefined( usable ) )
    {
        return;
    }
    msg = "Equip random Ammo Mod";
    self.cursed_arsenal_prompt_seen = gettime();
    if ( !isdefined( level.cursed_arsenal_prompt_text ) || level.cursed_arsenal_prompt_text != msg )
    {
        level.cursed_arsenal_prompt_text = msg;
        setdvar( "cursed_arsenal_prompt", msg );
    }
    if ( !istrue( level.cursed_arsenal_prompt_watch ) )
    {
        level thread arsenal_prompt_label_watch( self );
    }
}

function private arsenal_prompt_label_watch( player )
{
    level.cursed_arsenal_prompt_watch = 1;
    while ( isdefined( player ) && isdefined( player.cursed_arsenal_prompt_seen ) && gettime() - player.cursed_arsenal_prompt_seen < 250 )
    {
        wait 0.1;
    }
    level.cursed_arsenal_prompt_text = "";
    setdvar( "cursed_arsenal_prompt", "" );
    level.cursed_arsenal_prompt_watch = 0;
}

// ---------- v3.16: ARSENAL PROMPT RANGE (FIXED DISTANCE) ----------
// The engine starts calling the hint callback from well outside the distance
// at which the prompt can actually be used, so the "furthest hint call"
// measurement of v3.11-v3.15 was too large: the Lua text appeared far away.
// Now one fixed distance decides everything: inside it the prompt, the Lua
// text and the purchase are active; outside it the prompt is hidden (stock
// "HINT_NOICON" return) and Use does nothing. Measured flat (distance2d)
// from the player to the Arsenal interact point (25 units in front of the
// machine, init_arsenal_machine). 1 unit = 1 inch; 56 units = 1.4 m.
// Change ARSENAL_RANGE below to tune it.
function private arsenal_in_reduced_range( player )
{
    arsenal_range = 56; // ARSENAL_RANGE
    return distance2d( player.origin, self.origin ) <= arsenal_range;
}

// ---------- v3.14: REMOVE AETHER TOOLS (RARITY UPGRADE TOOLS) ----------
// Verified in mp/loot/common_item.gsc: every world item spawn (Mystery Box
// weapons, reward bundles of trials, Mister Peeks eggs, side Easter eggs,
// vault, drops, ...) passes through
//   callback::response( 1, #"item_spawn_allowed", { #itembundle } )
// common/callbacks.gsc _evaluate_response(): with type 1 the spawn is
// cancelled as soon as ANY handler returns false (0). So this handler must
// return true for every item and false only for Aether Tools.
// (v3.14 had this inverted, which blocked every item except Aether Tools,
// including the Mystery Box weapon.) The four tool tiers are
// itemspawnentry zm_t10_item_aether_tool(_2/_3/_4) with refs t10_aethertool,
// t10_aethertool2/3/4. Aether Crystals (PaP items) are NOT affected.
function private veto_aether_tool_spawn( params )
{
    if ( !supported_mode() || !isdefined( params ) || !isdefined( params.itembundle ) )
    {
        return true; // allowed
    }
    ref = params.itembundle.ref;
    if ( isdefined( ref ) && isstring( ref ) && issubstr( ref, "aethertool" ) )
    {
        return false; // Aether Tool: spawn cancelled
    }
    return true; // everything else: allowed
}

// ---------- v3.18: CLASSIC KNIFE (MELEE MACCHIATO - MOCHA MAUL) ----------
// Verified in the BO7 dump:
//  - Mocha Maul is augment #"m_mod_panic_knife" ("The punch is replaced with
//    your Dedicated Melee Weapon"). perk_m_mod.gsc / m_mod_augments.gsc give
//    the engine perk "specialty_melee_without_swap" while the player has
//    Melee Macchiato (specialty_m_mod) AND that augment, and remove it for
//    the weapons in level.var_37cff8154b47b497 (Firefly / Hornet Wonder
//    Weapons) and m_mod_augments::function_dc2626f05ee229f9() (spear / spike
//    attachments). vintage.gsc gives the same perk on its own.
//  - zombie_augments::give_player_bonus_augment() adds an augment to the
//    BONUS list (bonusmajoraugments / bonusminoraugments), which
//    player_has_augment() accepts, without using a selection slot - the
//    stock way perks, field upgrades and ammo mods grant extra augments.
// So: (1) Mocha Maul is given as a bonus augment, so with Melee Macchiato
// the stock code runs it next to the player's own augments; (2) without
// Melee Macchiato the same perk is given directly, with the same weapon
// exclusions, so the melee button uses the knife (classic knife) from spawn.

function private classic_knife_on_spawn()
{
    // One watcher per player; a respawn replaces the previous one.
    self notify( #"cursed_classic_knife" );
    self endon( #"cursed_classic_knife" );
    self endon( #"disconnect" );
    level endon( #"game_ended" );
    // Stock loadout hand-out runs ~1 s after spawn (zombie_mode_modifiers).
    wait 1.5;
    self classic_knife_give_bonus_augment();
    self classic_knife_update( self getcurrentweapon() );

    // v3.22: the perk is given back whenever it is missing (also after a
    // down). No forced remove/re-give any more (v3.20/v3.21 did that and
    // broke the knife). The stock Mocha Maul weapon-change handler now also
    // runs for every player (see classic_knife_augment_check below).
    while ( supported_mode() )
    {
        wait 0.5;
        if ( isalive( self ) && !self hasperk( "specialty_melee_without_swap" ) )
        {
            self classic_knife_update( self getcurrentweapon() );
        }
    }
}

function private classic_knife_give_bonus_augment()
{
    if ( !istrue( level.zombie_augments_in_use ) || !isdefined( level.zombie_augments ) )
    {
        return;
    }
    bundle = level.zombie_augments[ #"m_mod_panic_knife" ];
    if ( !isdefined( bundle ) || !isdefined( self.zombie_augments ) || !isdefined( self.zombie_augments[ bundle.augmenttype ] ) )
    {
        return;
    }
    self zombie_augments::give_player_bonus_augment( #"m_mod_panic_knife", #"unknown" );
}

function private classic_knife_banned( weapon )
{
    if ( !isdefined( weapon ) || !isweapon( weapon ) )
    {
        return false;
    }
    if ( isdefined( level.var_37cff8154b47b497 ) )
    {
        foreach ( weapon_name in level.var_37cff8154b47b497 )
        {
            if ( weapon.basename == weapon_name )
            {
                return true;
            }
        }
    }
    return m_mod_augments::function_dc2626f05ee229f9( weapon );
}

// self = player
function private classic_knife_update( weapon )
{
    if ( !supported_mode() || !isalive( self ) )
    {
        return;
    }
    if ( self classic_knife_banned( weapon ) )
    {
        if ( self hasperk( "specialty_melee_without_swap" ) )
        {
            perk::removeperk( "specialty_melee_without_swap" );
        }
        return;
    }
    if ( !self hasperk( "specialty_melee_without_swap" ) )
    {
        perk::giveperk( "specialty_melee_without_swap" );
    }
}

// weapons.gsc watchchangeweapon(): self = player, params.weapon = new weapon.
function private classic_knife_on_weapon_change( params )
{
    if ( supported_mode() && isplayer( self ) )
    {
        weapon = undefined;
        if ( isdefined( params ) )
        {
            weapon = params.weapon;
        }
        self classic_knife_update( weapon );
    }
}

// Losing Melee Macchiato runs perk_m_mod::take_m_mod_perk(), which removes
// specialty_melee_without_swap; give it back on the next frame.
function private classic_knife_on_perk_lost( params )
{
    if ( supported_mode() && isplayer( self ) )
    {
        self thread classic_knife_restore();
    }
}

function private classic_knife_restore()
{
    self endon( #"disconnect" );
    waitframe();
    self classic_knife_update( self getcurrentweapon() );
}

// ---------- v3.22: MOCHA MAUL WITHOUT MELEE MACCHIATO ----------
// Same technique as zm_armor_health_rework.gsc (Vulture Aid "replate"
// without the perk): wrap the stock shared function
//   #"zombie" / #"hash_3930894d8d2f0ee6" ( perkname, augmentname )
// which every script uses for "has this perk AND this augment"
// (m_mod_augments::m_mod_on_player_weapon_change, perk_m_mod give/think,
// zombie_damage::function_b1972eb8e4bd7e8f, ...). For
// ( "specialty_m_mod", #"m_mod_panic_knife" ) it answers yes, so the stock
// Mocha Maul code runs for every player without the perk:
//  - the weapon-change handler gives/removes specialty_melee_without_swap
//    with the stock weapon exclusions (classic knife on the melee button);
//  - Mocha Maul's stock knife damage applies (zombie_damage: a melee hit
//    deals a base zombie's full health up to the perk bundle's
//    maxdamageround, 20 by default).
// Every other perk / augment question goes to the original function.
function private classic_knife_install_augment_check()
{
    level endon( #"game_ended" );
    while ( !utility::issharedfuncdefined( #"zombie", #"hash_3930894d8d2f0ee6" ) )
    {
        waitframe();
    }
    if ( istrue( level.cursed_classic_knife_check_wrapped ) )
    {
        return;
    }
    level.cursed_classic_knife_check_wrapped = 1;
    level.cursed_classic_knife_orig_check = level.sharedfuncs[ #"zombie" ][ #"hash_3930894d8d2f0ee6" ];
    level.sharedfuncs[ #"zombie" ][ #"hash_3930894d8d2f0ee6" ] = &classic_knife_augment_check;
}

function private classic_knife_augment_check( perkname, augmentname )
{
    if ( perkname === "specialty_m_mod" && augmentname === #"m_mod_panic_knife" && supported_mode() )
    {
        return 1;
    }
    return self [[ level.cursed_classic_knife_orig_check ]]( perkname, augmentname );
}
